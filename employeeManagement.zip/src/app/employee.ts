export class Employee {
    id!: number;
    firstName!: string;
    lastname!: string;
    emailId!: string;
}
